// Initialize and add the map
var map;
var friendMarkers = [];
var friend_show = true;

var neighbourMarkers = [];
var neighbour_show = true;

var blockRectangles = [];
var block_show = true;

var hoodRectangle;
var hood_show = true;

var real_uid = new URL(location.href).searchParams.get('uid');

function initMap() {
var loc1 = {lat: 40.636851, lng: -74.0326267};
var loc2 = {lat: 40.634520, lng: -74.021227};
map = new google.maps.Map(
    document.getElementById('right_block'),
    { zoom: 17,
      disableDefaultUI: true,
      zoomControl: true});

var legend = document.getElementById('legend');

var div = document.createElement('div');
var icon = "/resources/red-blank.png";
var name = "Friends";
div.innerHTML = '<img src="' + icon + '"> ' + name;
legend.appendChild(div);

var div = document.createElement('div');
var icon = "/resources/ylw-blank.png";
var name = "Neighbours";
div.innerHTML = '<img src="' + icon + '" width=16px height=24px> ' + name;
legend.appendChild(div);

var div = document.createElement('div');
var icon = "/resources/blu-blank-lv.png";
var name = "Block";
div.innerHTML = '<img src="' + icon + '"> ' + name;
legend.appendChild(div);

var div = document.createElement('div');
var icon = "/resources/grn-blank-lv.png";
var name = "Hood";
div.innerHTML = '<img src="' + icon + '"> ' + name;
legend.appendChild(div);

var div = document.createElement('div');
var icon = "/resources/home.png";
var name = "Home";
let size = '20px';
div.innerHTML = `<img src='${icon}' alt=${name}/> ${name}`;
legend.appendChild(div);

map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);

// Add legend

legend.childNodes[1].addEventListener("click", function(){
  friend_show = !friend_show;
  for(let i=0;i<friendMarkers.length;i++){
    friendMarkers[i].setVisible(friend_show);
  }
});

legend.childNodes[2].addEventListener("click", function(){
  neighbour_show = !neighbour_show;
  for(let i=0;i<neighbourMarkers.length;i++){
    neighbourMarkers[i].setVisible(neighbour_show);
  }
});

legend.childNodes[3].addEventListener("click", function(){
  block_show = !block_show;
  for(let i=0;i<blockRectangles.length;i++){
    blockRectangles[i].setVisible(block_show);
  }
});

legend.childNodes[4].addEventListener("click", function(){
  hood_show = !hood_show;
  hoodRectangle.setVisible(hood_show);
});

// End add legend

var request = async()=>{
  var response = await fetch('http://localhost:3000/getFriendMarker/' + real_uid);
  var myJson = await response.json();
  submit_friends(myJson);
  putFriendMarkers(myJson);

  var response = await fetch('http://localhost:3000/getNeighbourMarker/' + real_uid);
  var myJson = await response.json();
  submit_neighbours(myJson);
  putNeighbourMarkers(myJson);

  var response = await fetch('http://localhost:3000/getHome/' + real_uid);
  var data = await response.json();
  loc = {lat: data["ux"], lng: data["uy"]};
  var homeMarker = new google.maps.Marker({position:loc,map:map,icon:"/resources/home.png"});
  map.setCenter(new google.maps.LatLng(loc["lat"], loc["lng"]));

  var response = await fetch('http://localhost:3000/getBlocks/' + real_uid);
  var myJson = await response.json();
  putBlocks(myJson);

  var response = await fetch('http://localhost:3000/getBlockMembers/' + real_uid);
  var myJson = await response.json();
  submit_block_members(myJson);

  var response = await fetch('http://localhost:3000/getHoodMembers/' + real_uid);
  var myJson = await response.json();
  submit_hood_members(myJson);

  var response = await fetch('http://localhost:3000/getHood/' + real_uid);
  var data = await response.json();
  var bounds = {
    north: data[0]["hnorthx"],//top
    south: data[0]["hsouthx"],//bottom
    east: data[0]["hnorthy"],//right
    west: data[0]["hsouthy"]//left
  };
  hoodRectangle = new google.maps.Rectangle({
    bounds: bounds, fillColor: 'green', strokeOpacity: 0.3, strokeWeight: 2, strokeColor: 'green', fillOpacity: 0.35, editable: false, map:map
  });


}
request();

async function showProfile(usrid){
  document.getElementById("friend_status").innerHTML ="";
  document.getElementById('right_block').style.visibility="hidden";

  profile_window = document.querySelector(".former");
  profile_window.style.display= "inline-block";
  var response = await fetch('http://localhost:3000/getUserdata/'+usrid+'/'+real_uid);
  var profileData = await response.json();

  var response = await fetch('http://localhost:3000/checkfriendstatus/'+usrid+'/'+real_uid);
  var isFriend = await response.json();

  //console.log();

  profileArea = document.getElementById("profile_data").getElementsByTagName("p");

  pimage = document.getElementById("profile_image");
  var style = "style=\"height: 60px ; width: 60px; border-radius: 50%; border: 1px solid #c4c4c4>\""; 
  pimage.innerHTML = `<img src='${profileData[0]["uphoto"]}' '+${style}+" </img>`;

  profileArea[0].innerText = "Username: "+profileData[0]["uname"];
  profileArea[1].innerText = "Email: "+profileData[0]["uemail"];
  if (profileData[0]["uaddress"]==""){
    profileArea[2].innerText = "Address: No Data Provided";
  }
  else{
    profileArea[2].innerText = "Address: "+profileData[0]["uaddress"];
  }
  if (profileData[0]["uprofile"]==""){
    profileArea[3].innerText = "Profile: No Data Provided";
  }
  else{
    profileArea[3].innerText = "Profile: "+profileData[0]["uprofile"];
  }

  b1 = document.getElementById("add_friend")
  b1.style.visibility="visible";

  if (isFriend[0]["count"]==2){
    b1.style.visibility="hidden";
    document.getElementById("friend_status").innerHTML = "Already Friends";
  }

  else if (isFriend[0]["count"]==1){
    b1.style.visibility="hidden";
    document.getElementById("friend_status").innerHTML = "Friend request sent";
  }
  else{
    var query = await fetch('http://localhost:3000/checkfriendstatus/'+usrid+'/'+real_uid);
  }

  b1.onclick= async function(){
    var query = await fetch('http://localhost:3000/sendFriendRequest/'+usrid+'/'+real_uid);
    b1.style.visibility="hidden";
    document.getElementById("friend_status").innerHTML = "Friend Request Sent";
  }

  b2 = document.getElementById("close_button");
  b2.onclick=function(){
    profile_window.style.display= "none";
    document.getElementById('right_block').style.visibility="visible";
  }

}


function submit_friends(data){
  chat  = document.getElementById("friends");
  for(let i=0;i<data.length;i++){
    item = document.createElement('div');
    item.classList.add("chat_people");
      uphoto = document.createElement('div');
      uphoto.classList.add("chat_img");
      uphoto.innerHTML=`<img src='${data[i]["uphoto"]}'></img>`;
    item.appendChild(uphoto);
      uname = document.createElement('div');
      uname.classList.add("chat_ib");
      uname.innerHTML=`<H5>${data[i]["uname"]}</H5>`;
    item.appendChild(uname);
      uid = document.createElement('div');
      uid.classList.add("chat_uid");
      uid.innerHTML=`<H5>${data[i]["fid"]}</H5>`;
    item.appendChild(uid);
    item.onclick=function(){
      uid = this.getElementsByClassName("chat_uid")[0].innerText;
      showProfile(uid);
    };
    chat.appendChild(item);
  }
}

function submit_neighbours(data){
  chat  = document.getElementById("neighbours");
  for(let i=0;i<data.length;i++){
    item = document.createElement('div');
    item.classList.add("chat_people");
      uphoto = document.createElement('div');
      uphoto.classList.add("chat_img");
      uphoto.innerHTML=`<img src='${data[i]["uphoto"]}'></img>`;
    item.appendChild(uphoto);
      uname = document.createElement('div');
      uname.classList.add("chat_ib");
      uname.innerHTML=`<H5>${data[i]["uname"]}</H5>`;
    item.appendChild(uname);
      uid = document.createElement('div');
      uid.classList.add("chat_uid");
      uid.innerHTML=`<H5>${data[i]["nid"]}</H5>`;
    item.appendChild(uid);
    item.onclick=function(){
      uid = this.getElementsByClassName("chat_uid")[0].innerText;
      showProfile(uid);
    };
    chat.appendChild(item);
  }
}

function submit_block_members(data){
  chat  = document.getElementById("block");
  for(let i=0;i<data.length;i++){
    if (data[i]["uid"]!=2){
      item = document.createElement('div');
    item.classList.add("chat_people");
      uphoto = document.createElement('div');
      uphoto.classList.add("chat_img");
      uphoto.innerHTML=`<img src='${data[i]["uphoto"]}'></img>`;
    item.appendChild(uphoto);
      uname = document.createElement('div');
      uname.classList.add("chat_ib");
      uname.innerHTML=`<H5>${data[i]["uname"]}</H5>`;
    item.appendChild(uname);
      uid = document.createElement('div');
      uid.classList.add("chat_uid");
      uid.innerHTML=`<H5>${data[i]["uid"]}</H5>`;
    item.appendChild(uid);
    item.onclick=function(){
      uid = this.getElementsByClassName("chat_uid")[0].innerText;
      showProfile(uid);
    };
    chat.appendChild(item);
    }
  }
}

function submit_hood_members(data){
  chat  = document.getElementById("hood");
  for(let i=0;i<data.length;i++){
    if (data[i]["uid"]!=2){
      item = document.createElement('div');
    item.classList.add("chat_people");
      uphoto = document.createElement('div');
      uphoto.classList.add("chat_img");
      uphoto.innerHTML=`<img src='${data[i]["uphoto"]}'></img>`;
    item.appendChild(uphoto);
      uname = document.createElement('div');
      uname.classList.add("chat_ib");
      uname.innerHTML=`<H5>${data[i]["uname"]}</H5>`;
    item.appendChild(uname);
      uid = document.createElement('div');
      uid.classList.add("chat_uid");
      uid.innerHTML=`<H5>${data[i]["uid"]}</H5>`;
    item.appendChild(uid);
    item.onclick=function(){
      uid = this.getElementsByClassName("chat_uid")[0].innerText;
      showProfile(uid);
    };
    chat.appendChild(item);
    }
  }
}

function putFriendMarkers(data){
  for(let i= 0;i<data.length;i++){
    loc = {lat: data[i]["ux"], lng: data[i]["uy"]};
    var marker = new google.maps.Marker({position:loc,map:map,label:data[i]["uname"]});
    friendMarkers.push(marker);
  }
}

function putNeighbourMarkers(data){
  for(let i= 0;i<data.length;i++){
    loc = {lat: data[i]["ux"], lng: data[i]["uy"]};
    var marker = new google.maps.Marker({position:loc,map:map,icon:"/resources/ylw-blank.png",label:data[i]["uname"]});
    neighbourMarkers.push(marker);
  }
}

function putBlocks(data){
  // console.log(data)
  for(let i=0;i<data.length;i++){
    var bounds = {
      north: data[i]["bnorthx"],//top
      south: data[i]["bsouthx"],//bottom
      east: data[i]["bnorthy"],//right
      west: data[i]["bsouthy"]//left
    };
    var rectangle = new google.maps.Rectangle({
      bounds: bounds, fillColor: 'blue', strokeOpacity: 0.3, strokeWeight: 2, strokeColor: 'blue', fillOpacity: 0.35, editable: false, map:map
    });
    blockRectangles.push(rectangle);
  }
}

}//init end

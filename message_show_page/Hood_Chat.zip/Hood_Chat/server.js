var express = require('express');
var app = express();
const mysql = require('mysql2');

app.use(express.static('static_file'));

app.get('/', function(req, res) {

})

// GET accessible thread
app.get('/all_thread/:uid', function (req, res) {
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Zz100xy;',
        database: 'hood_chat'
    });
    
    connection.execute(
        'select `thid` ' + 
        'from `contains` ' + 
        'where `contains`.`tid` in (select `tid` ' + 
                                    'from `topic` natural join `specifies` ' + 
                                    'where `specifies`.`uid` = ?)',
        [req.params.uid],
        function(err, results, fields) {
            if (err) {
                throw err;
            }
            console.log('Get results for accessible thread [' + new Date().toLocaleString() + ']');
            console.log(results);
            res.json(results);
            connection.destroy();
        }
    );
})

// GET latest message
app.get('/latest_message/:thid/:uid', function (req, res) {
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Zz100xy;',
        database: 'hood_chat'
    });
    // console.log(req.params.thid);
    // console.log(req.params.uid);
    connection.execute(
        'select max(mtimestamp) as `max_timestamp` ' + 
        'from (select `has`.`mid` as `mid` ' + 
                'from `has` ' + 
                'where `thid` = ? and `has`.`mid` in (select `mid` ' + 
                                                    'from `accesses` ' + 
                                                    'where `accesses`.`uid` = ?)) as `T0` ' +
                'natural join `message`',
        [req.params.thid, req.params.uid],
        function(err, results, fields) {
            if (err) {
                throw err;
            }
            console.log('Get results for thread message max timestamp [' + new Date().toLocaleString() + ']');
            console.log(results);

            var time = results;
            connection.execute(
                'select * ' + 
                'from (`has` natural join `message`) join `user` on `message`.`uid` = `user`.`uid` ' + 
                'where `thid` = ? and `mtimestamp` = ?',
                [req.params.thid, time[0].max_timestamp],
                function(err, results, fields) {
                    if (err) {
                        throw err;
                    }
                    console.log('Get results for thread latest message [' + new Date().toLocaleString() + ']');
                    console.log(results);
                    res.json(results);
                    connection.destroy();
                }
            )
        }
    );
})

// GET complete thread message
app.get('/thread_message/:thid/:uid', function (req, res) {
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Zz100xy;',
        database: 'hood_chat'
    });
    
    connection.execute(
        'select * ' + 
        'from (select `has`.`mid` as `mid` ' + 
                'from `has` ' + 
                'where `thid` = ? and `has`.`mid` in (select `mid` ' + 
                                                    'from `accesses` ' + 
                                                    'where `accesses`.`uid` = ?)) as `T0` ' +
                'natural join `message`',
        [req.params.thid, req.params.uid],
        function(err, results, fields) {
            if (err) {
                throw err;
            }
            console.log('Get results for accessible complete thread message [' + new Date().toLocaleString() + ']');
            console.log(results);
            res.json(results);
            connection.destroy();
        }
    );
})

// GET search message
app.get('/search_msg/:keywords/:uid', function (req, res) {
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Zz100xy;',
        database: 'hood_chat'
    });
    // console.log(req.params.keywords);
    // console.log(req.params.uid);
    
    connection.execute(
        'select * ' + 
        'from (select `has`.`mid` as `mid` ' + 
                'from `has` ' + 
                'where `has`.`mid` in (select `mid` ' + 
                                        'from `accesses` ' + 
                                        'where `accesses`.`uid` = ?)) as `T0` ' +
                'natural join `message` ' +
        'where `message`.`mtext` like ?',
        [req.params.uid, '%' + req.params.keywords + '%'],
        function(err, results, fields) {
            if (err) {
                throw err;
            }
            console.log('Get results for search message [' + new Date().toLocaleString() + ']');
            console.log(results);
            res.json(results);
            connection.destroy();
        }
    );
})
  
// POST method route
app.post('/', function (req, res) {
    res.send('POST request to the homepage');
})

app.listen(9229, () => {
    console.log('Server started at http://localhost:9229/ [' + new Date().toLocaleString() + ']');
});
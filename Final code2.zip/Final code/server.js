const express = require('express');
const app = express();
const mysql = require('mysql2');

app.use(express.static('static_files'));

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database:"hood_chat"
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});


app.get('/getFriendMarker',function (req,res){
  connection.execute(
      'call friend_location(?);',
      [2],
      function(err, results, fields) {
        // console.log("friend marker");
        // console.log(results[0]); // results contains rows returned by server
        res.json(results[0]);
      }
    );
});

app.get('/sendFriendRequest/:usrid/:uid',function (req,res){
  connection.execute(
      'insert into friends values(?,?);',
      [req.params.uid,req.params.usrid],
      function(err, results, fields) {
        // console.log("Neighbour marker");
        console.log(results); // results contains rows returned by server
        res.json(results);
      }
    );
});

app.get('/deleteFriendRequest/:usrid/:uid',function (req,res){
  connection.execute(
      'delete from friends where uid=? and fid=?;',
      [req.params.uid,req.params.usrid],
      function(err, results, fields) {
        // console.log("Neighbour marker");
        //console.log(results); // results contains rows returned by server
        res.json(results);
      }
    );
});


app.get('/getRequests',function (req,res){
  connection.execute(
      'call get_requests(?);',
      [2],
      function(err, results, fields) {
        // console.log("Neighbour marker");
        // console.log(results[0]); // results contains rows returned by server
        res.json(results[0]);
      }
    );
});


app.get('/getNeighbourMarker',function (req,res){
  connection.execute(
      'call neighbour_location(?);',
      [2],
      function(err, results, fields) {
        // console.log("Neighbour marker");
        // console.log(results[0]); // results contains rows returned by server
        res.json(results[0]);
      }
    );
});

app.get('/getHome',function (req,res){
  connection.execute(
      'select uname,ux,uy from user where uid=?',
      [2],
      function(err, results, fields) {
        // console.log("Get Home");
        // console.log(results[0]); // results contains rows returned by server
        res.json(results[0]);
      }
    );
});

app.get('/getBlockMembers',function (req,res){
  connection.execute(
      'select uname,user.uid,uphoto,ux,uy from user join (select * from ins where bid=(select bid from ins where uid = ?)) as block_members on user.uid=block_members.uid;',
      [2],
      function(err, results, fields) {
        //  console.log("Get Blocks");
        //  console.log(results); // results contains rows returned by server
        res.json(results);
      }
    );
});

app.get('/getHoodMembers',function (req,res){
  connection.execute(
      'select uname,user.uid,uphoto,ux,uy from user join (select * from ins where bid in (select bid from belongs where hid = (select hid from belongs where bid = (select bid from ins where uid = ?)))) as hood_members on user.uid=hood_members.uid;',
      [2],
      function(err, results, fields) {
        // console.log("Get Hood");
        // console.log(results); // results contains rows returned by server
        res.json(results);
      }
    );
});


app.get('/getUserdata/:usrid/:uid', function (req, res) {
  connection.execute(
    'select * from user where uid=?',
    [req.params.usrid],
    function(err, results, fields) {
      //  console.log("Get Blocks");
      //  console.log(results); // results contains rows returned by server
      res.json(results);
    }
  );
});

app.get('/checkfriendstatus/:usrid/:uid', function (req, res) {
  connection.execute(
    'select count(*) as count from (select * from friends where uid = ? and fid = ? union select * from friends where uid = ? and fid = ?) as t;',
    [req.params.usrid,req.params.uid,req.params.uid,req.params.usrid],
    function(err, results, fields) {
      //  console.log("Get Blocks");
      // console.log(results); // results contains rows returned by server
      res.json(results);
    }
  );
});

app.get('/getBlocks',function (req,res){
  connection.execute(
      'call block_locations(?);',
      [2],
      function(err, results, fields) {
        // console.log("Get Blocks");
        // console.log(results[0]); // results contains rows returned by server
        res.json(results[0]);
      }
    );
});

app.get('/getHood',function (req,res){
  connection.execute(
      'call hood_location(?);',
      [2],
      function(err, results, fields) {
        // console.log("Get Hood");
        // console.log(results[0]); // results contains rows returned by server
        res.json(results[0]);
      }
    );
});

app.get('/all_thread', function (req, res) {
  connection.execute(
    'select `thid` ' + 
    'from `contains` ' + 
    'where `contains`.`tid` in (select `tid` ' + 
                                'from `topic` natural join `specifies` ' + 
                                'where `specifies`.`uid` = ?)',
    [2],
    function(err, results, fields) {
       //console.log('Get results for accessible thread [' + new Date().toLocaleString() + ']');
        //console.log(results);
        res.json(results);
    });
});

app.get('/latest_message/:thid/:uid', function (req, res) {
  // console.log(req.params.thid);
  // console.log(req.params.uid);
  connection.execute(
      'select max(mtimestamp) as `max_timestamp` ' + 
      'from (select `has`.`mid` as `mid` ' + 
              'from `has` ' + 
              'where `thid` = ? and `has`.`mid` in (select `mid` ' + 
                                                  'from `accesses` ' + 
                                                  'where `accesses`.`uid` = ?)) as `T0` ' +
              'natural join `message`',
      [req.params.thid, req.params.uid],
      function(err, results, fields) {
          // console.log('Get results for thread message max timestamp [' + new Date().toLocaleString() + ']');
          // console.log(results);

          var time = results;
          connection.execute(
              'select * ' + 
              'from (`has` natural join `message`) join `user` on `message`.`uid` = `user`.`uid` ' + 
              'where `thid` = ? and `mtimestamp` = ?',
              [req.params.thid, time[0].max_timestamp],
              function(err, results, fields) {
                  // console.log('Get results for thread latest message [' + new Date().toLocaleString() + ']');
                  // console.log(results);
                  res.json(results);
              }
          )
      }
  );
});


app.listen(3000,()=>{
    console.log("Server started");
})
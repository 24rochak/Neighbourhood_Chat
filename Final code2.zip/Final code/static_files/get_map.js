var map;

var blockRectangles = [];
var block_show = true;

var hoodRectangle;
var hood_show = true;
var search_active = false;

var messageMarkers = [];
var messageShow=true;

var messages=[];
var infoWins = []

var searchRectangle;

function initMap() {
var loc1 = {lat: 40.636851, lng: -74.0326267};
var loc2 = {lat: 40.634520, lng: -74.021227};
map = new google.maps.Map(
    document.getElementById('right_block'),
    { zoom: 15,
      disableDefaultUI: true,
      zoomControl: true});

var legend = document.getElementById('legend');

var div = document.createElement('div');
var icon = "/resources/blu-blank-lv.png";
var name = "Block";
div.innerHTML = '<img src="' + icon + '"> ' + name;
legend.appendChild(div);

var div = document.createElement('div');
var icon = "/resources/grn-blank-lv.png";
var name = "Hood";
div.innerHTML = '<img src="' + icon + '"> ' + name;
legend.appendChild(div);

var div = document.createElement('div');
var icon = "/resources/home.png";
var name = "Home";
let size = '20px';
div.innerHTML = `<img src='${icon}' alt=${name}/> ${name}`;
legend.appendChild(div);

map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);
// Add legend

var search = document.getElementById('search');
map.controls[google.maps.ControlPosition.LEFT_TOP].push(search);

var searchButton =  document.getElementById('search_button');
searchButton.addEventListener("click",function(){
  if (!search_active){
    search_active = true;
    findButton.style.visibility = 'visible';
    block_show = !block_show;
    for(let i=0;i<blockRectangles.length;i++){
      blockRectangles[i].setVisible(block_show);
    }
    hood_show = !hood_show;
    hoodRectangle.setVisible(hood_show);

    messageShow = !messageShow;
    for(let i=0;i<messageMarkers.length;i++){
        messageMarkers[i].setVisible(messageShow);
    }

    for(let i=0;i<infoWins.length;i++){
      infoWins[i].close();
  }
  var center = map.getCenter().toJSON();

  searchRectangle = new google.maps.Rectangle({
    strokeColor: 'grey',
    strokeOpacity: 0.8,
    strokeWeight: 2,
    fillColor: 'grey',
    fillOpacity: 0.35,
    map: map,
    editable:true,
    draggable: true,
    bounds: {
      north: center["lat"]+0.002,
      south: center["lat"]-0.002,
      east: center["lng"]+0.003,
      west: center["lng"]-0.003
    }
  });

  }
});

var findButton =  document.getElementById('find_button');
findButton.addEventListener("click",function(){
  var bounds = searchRectangle.getBounds();
  for(let i=0;i<messageMarkers.length;i++){
    messageMarkers[i].setVisible(false);
}
  for(let i=0;i<messages.length;i++){
    if (bounds['pa']['g']<messages[i]["mx"] && messages[i]["mx"]<bounds['pa']['h'] && bounds['ka']['g']<messages[i]["my"] && messages[i]["my"]<bounds['ka']['h']) {
      messageMarkers[i].setVisible(true);
    }
  }
});

var exitButton =  document.getElementById('exit_button');

exitButton.addEventListener("click",function(){
  if (search_active){
    search_active = false;
    findButton.style.visibility = 'hidden';
    searchRectangle.setMap(null);
    block_show = !block_show;
  for(let i=0;i<blockRectangles.length;i++){
    blockRectangles[i].setVisible(block_show);
  }
  hood_show = !hood_show;
  hoodRectangle.setVisible(hood_show);

  messageShow = !messageShow;
  for(let i=0;i<messageMarkers.length;i++){
      messageMarkers[i].setVisible(messageShow);
  }

  for(let i=0;i<infoWins.length;i++){
    infoWins[i].close();
}
  }
});


legend.childNodes[1].addEventListener("click", function(){
  block_show = !block_show;
  for(let i=0;i<blockRectangles.length;i++){
    blockRectangles[i].setVisible(block_show);
  }
});

legend.childNodes[2].addEventListener("click", function(){
  hood_show = !hood_show;
  hoodRectangle.setVisible(hood_show);
});

// End add legend

var request = async()=>{
  var response = await fetch('http://localhost:3000/getHome');
  var data = await response.json();
  loc = {lat: data["ux"], lng: data["uy"]};
  var homeMarker = new google.maps.Marker({position:loc,map:map,icon:"/resources/home.png"});
  map.setCenter(new google.maps.LatLng(loc["lat"], loc["lng"]));

  var response = await fetch('http://localhost:3000/getBlocks');
  var myJson = await response.json();
  putBlocks(myJson);

  var response = await fetch('http://localhost:3000/getHood');
  var data = await response.json();
  var bounds = {
    north: data[0]["hnorthx"],//top
    south: data[0]["hsouthx"],//bottom
    east: data[0]["hnorthy"],//right
    west: data[0]["hsouthy"]//left
  };
  hoodRectangle = new google.maps.Rectangle({
    bounds: bounds, fillColor: 'green', strokeOpacity: 0.3, strokeWeight: 2, strokeColor: 'green', fillOpacity: 0.35, editable: false, map:map
  });

  var response = await fetch('http://localhost:3000/all_thread');
  var myJson = await response.json();
  for(let i=0;i<myJson.length;i++){
    var response2 = await fetch('http://localhost:3000/latest_message/'+myJson[i]["thid"]+'/2');
    var myJson2 = await response2.json();
    putMessage(myJson2[0]);
  }

};
request();

function putMessage(data){
  loc = {lat: data["mx"], lng: data["my"]};
  var marker = new google.maps.Marker({position:loc,map:map,icon:{url:"/resources/envelope.png",labelOrigin:new google.maps.Point(55, 12)},label:{text:data["uname"],color:'black',fontWeight:'bold',}});
  var infowindow = new google.maps.InfoWindow({content: data["mtext"]});
  marker.addListener('click', function() {
    infowindow.open(map, marker);
  });
  messageMarkers.push(marker);
  messages.push(data);
  infoWins.push(infowindow);
}

function putBlocks(data){
  // console.log(data)
  for(let i=0;i<data.length;i++){
    var bounds = {
      north: data[i]["bnorthx"],//top
      south: data[i]["bsouthx"],//bottom
      east: data[i]["bnorthy"],//right
      west: data[i]["bsouthy"]//left
    };
    var rectangle = new google.maps.Rectangle({
      bounds: bounds, fillColor: 'blue', strokeOpacity: 0.3, strokeWeight: 2, strokeColor: 'blue', fillOpacity: 0.35, editable: false, map:map
    });
    blockRectangles.push(rectangle);
  }
}

}//init end
